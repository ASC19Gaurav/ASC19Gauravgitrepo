import {
  MatDivider,
  MatDividerModule
} from "./chunk-SDVEUAH3.js";
import "./chunk-7KTITPXM.js";
import "./chunk-JS2GI3JY.js";
import "./chunk-JYXXJTPI.js";
import "./chunk-5TID76VL.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
