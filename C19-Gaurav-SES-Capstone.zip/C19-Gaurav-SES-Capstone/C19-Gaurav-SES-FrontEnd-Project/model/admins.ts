export class AdminUser{
    constructor(
      public id:string,
       public name: string,
       public age: number,
       public phone: number,
       public email: string,
       public password:string
      
     ){

    }

}