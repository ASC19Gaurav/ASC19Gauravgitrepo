export class Ticket{
    constructor(
      public id:string,
       public name: string,
       public age : number,
       public matchName: string,
       public quantity   :number,
       public date:string,
      
     ){

    }

}