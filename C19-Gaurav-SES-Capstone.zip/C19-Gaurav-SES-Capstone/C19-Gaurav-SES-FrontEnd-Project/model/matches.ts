export class Matches{
    constructor(
       public id: string,
       public matchName: string,
       public matchDate: string,
       public matchLocation: string,
       public team1Name:string,
       public team2Name:string,
       public tournamentName:string
      
     ){

    }

}