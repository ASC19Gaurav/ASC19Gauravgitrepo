export class Player{
    constructor(
      public id:string,
       public playerName: string,
       public playerAge : number,
       public phoneNo: string,
       public teamName   :string
      
     ){

    }

}